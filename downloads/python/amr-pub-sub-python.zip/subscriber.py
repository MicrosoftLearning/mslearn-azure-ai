import os
import redis
import json
import threading
import time
from datetime import datetime
from queue import Queue
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

def connect_to_redis() -> redis.Redis:
    """Establish connection to Azure Managed Redis using SSL encryption and authentication"""
    try:
        redis_host = os.getenv("REDIS_HOST")
        redis_key = os.getenv("REDIS_KEY")
        
        r = redis.Redis(  # Create Redis connection object
            host=redis_host,
            port=10000,
            ssl=True,
            decode_responses=True,
            password=redis_key,
            socket_timeout=30,
            socket_connect_timeout=30,
        )
        
        # Test connection
        r.ping()  # Verify Redis connectivity
        return r
        
    except redis.ConnectionError as e:
        print(f"[x] Connection error: {e}")
        print("Check if Redis host and port are correct, and ensure network connectivity")
        raise
    except redis.AuthenticationError as e:
        print(f"[x] Authentication error: {e}")
        print("Make sure the access key is correct")
        raise
    except Exception as e:
        print(f"[x] Unexpected error: {e}")
        raise

# BEGIN MESSAGE FORMATTING CODE SECTION



# END MESSAGE FORMATTING CODE SECTION

class PubSubManager:
    """Manages Redis pub/sub operations and message listening"""
    
    def __init__(self):
        """Initialize the pub/sub manager with Redis connection and message queue"""
        self.r = connect_to_redis()
        self.pubsub = self.r.pubsub(ignore_subscribe_messages=True)  # Create pubsub object, filter subscription confirmations
        self.message_queue = Queue()
        self.listening = False
        self.listener_active = False
        self.listener_thread = None
    
    # BEGIN MESSAGE LISTENER CODE SECTION
    

    
    # END MESSAGE LISTENER CODE SECTION
    
    def restart_listener(self, clear_subs=False):
        """Restart the listener thread after subscription changes, optionally clearing subscriptions"""
        
        # Save current subscriptions before closing
        channels = list(self.pubsub.channels.keys()) if self.pubsub.channels else []  # Get current channel subscriptions
        patterns = list(self.pubsub.patterns.keys()) if self.pubsub.patterns else []  # Get current pattern subscriptions
        
        # If clear_subs is True, don't restore subscriptions
        if clear_subs:
            channels = []
            patterns = []
        
        # Stop the old listener if it's running
        if self.listener_thread and self.listener_thread.is_alive():
            self.listening = False
            # Wait for listener to fully stop
            max_wait = 10
            while self.listener_active and max_wait > 0:
                time.sleep(0.1)
                max_wait -= 1
        
        # Close old pubsub
        try:
            self.pubsub.close()  # Close pubsub connection
        except:
            pass
        
        time.sleep(0.1)
        
        # Create new pubsub object
        self.pubsub = self.r.pubsub(ignore_subscribe_messages=True)
        
        # Restore subscriptions
        if channels:
            self.pubsub.subscribe(*channels)  # Subscribe to channels
        if patterns:
            self.pubsub.psubscribe(*patterns)  # Subscribe to patterns (wildcard matching)
        
        # Start fresh listener
        self.listening = True
        self.listener_thread = threading.Thread(target=self.listen_messages, daemon=True)
        self.listener_thread.start()
    
    # BEGIN SUBSCRIBE CHANNEL/PATTERN CODE SECTION
    
    
    
    # END SUBSCRIBE CHANNEL/PATTERN CODE SECTION

    def unsubscribe_from_channel(self, channel: str) -> str:
        """Unsubscribe from a channel using pubsub.unsubscribe()"""
        try:
            self.pubsub.unsubscribe(channel)  # Unsubscribe from channel
            self.restart_listener()
            return f"[+] Unsubscribed from channel: '{channel}'"
        except Exception as e:
            return f"[x] Error unsubscribing: {e}"
    
    def unsubscribe_all(self) -> str:
        """Unsubscribe from all channels and patterns using pubsub.unsubscribe() and pubsub.punsubscribe()"""
        try:
            channels = list(self.pubsub.channels.keys()) if self.pubsub.channels else []  # Get subscribed channels
            patterns = list(self.pubsub.patterns.keys()) if self.pubsub.patterns else []  # Get subscribed patterns
            
            unsubscribed_channels = 0
            unsubscribed_patterns = 0
            
            if channels:
                for channel in channels:
                    self.pubsub.unsubscribe(channel)  # Unsubscribe from each channel
                    unsubscribed_channels += 1
            
            if patterns:
                for pattern in patterns:
                    self.pubsub.punsubscribe(pattern)  # Unsubscribe from each pattern
                    unsubscribed_patterns += 1
            
            self.restart_listener(clear_subs=True)
            return f"[+] Unsubscribed from {unsubscribed_channels} channel(s) and {unsubscribed_patterns} pattern(s)"
        except Exception as e:
            return f"[x] Error unsubscribing: {e}"
    
    def get_subscriptions(self) -> dict:
        """Get current active subscriptions from pubsub.channels and pubsub.patterns"""
        channels = self.pubsub.channels  # Get dict of subscribed channels
        patterns = self.pubsub.patterns  # Get dict of subscribed patterns
        
        return {
            'channels': list(channels.keys()) if channels else [],
            'patterns': list(patterns.keys()) if patterns else [],
            'listening': self.listening
        }
    
    def get_message(self, timeout=0.1):
        """Get next message from queue (non-blocking) for safe GUI polling"""
        try:
            return self.message_queue.get(timeout=timeout)
        except:
            return None
    
    def close(self):
        """Close Redis connections and stop the listener thread"""
        self.listening = False
        try:
            self.pubsub.close()  # Close pubsub connection
            self.r.close()  # Close Redis connection
        except:
            pass

if __name__ == "__main__":
    from subscriber_gui import run_gui
    run_gui()
